import { Award, Calendar, ExternalLink, Expand } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
// Using the uploaded certificate image directly
const pythonCertificate = "/lovable-uploads/c1a0f9ad-ab30-4728-a50b-8f8987b5f6ea.png";
const CertificatesSection = () => {
  const [selectedImage, setSelectedImage] = useState<{ src: string; title: string } | null>(null);
  const certificates = [{
    title: "Crash Course on Python",
    organization: "Google - Coursera",
    date: "2025",
    description: "مقدمة شاملة في برمجة Python والأساسيات",
    link: "https://coursera.org/share/3cad5bad2bfbfd50bc270ea6ac5767e2",
    image: "/lovable-uploads/48749b39-127f-47a6-b295-a3bb94cd59d1.png"
  }, {
    title: "Python 101 for Data Science",
    organization: "IBM - Cognitive Class",
    date: "2025",
    description: "Introduction to Python programming for data science applications",
    link: "https://courses.cognitiveclass.ai/certificates/2f8122454cbe4d2880ef26f125200827",
    image: pythonCertificate
  }, {
    title: "البرنامج التدريبي - كن قائداً",
    organization: "أكاديمية منشآت",
    date: "2025",
    description: "برنامج تدريبي في تطوير مهارات القيادة والإدارة",
    image: "/lovable-uploads/af7b38ed-5498-4031-bc45-c1d6eda312a2.png"
  }, {
    title: "Cyber Security",
    organization: "إدراك - Edraak",
    date: "2025",
    description: "شهادة تخصص شامل في الأمن السيبراني وتقنيات الحماية",
    image: "/lovable-uploads/cddce5c5-c2bb-4107-a09f-f9c3852c2649.png"
  }, {
    title: "Career path in Cyber Security",
    organization: "إدراك - Edraak",
    date: "2025",
    description: "مسار وظيفي في الأمن السيبراني ومجالات العمل المتاحة",
    image: "/lovable-uploads/0f80bdda-4235-4e21-911f-72ac993fbf50.png"
  }, {
    title: "Protect Systems from Penetrations",
    organization: "إدراك - Edraak",
    date: "2025",
    description: "حماية الأنظمة من الاختراقات وتقنيات الدفاع",
    image: "/lovable-uploads/80190677-e328-4548-bda0-03b412e22143.png"
  }, {
    title: "Cyber Security Attack Techniques",
    organization: "إدراك - Edraak",
    date: "2025",
    description: "تقنيات الهجمات السيبرانية وأدوات الاختبار",
    image: "/lovable-uploads/ee971f76-6a3b-4410-8a31-df24dd755892.png"
  }, {
    title: "Cyber Security Basics",
    organization: "إدراك - Edraak",
    date: "2025",
    description: "أساسيات الأمن السيبراني والمفاهيم الأساسية",
    image: "/lovable-uploads/23b95f52-fba8-4027-ae98-653d6d918034.png"
  }, {
    title: "Introduction to Cyber Security",
    organization: "إدراك - Edraak",
    date: "2025",
    description: "مقدمة في الأمن السيبراني والحماية الرقمية",
    image: "/lovable-uploads/b5fa856a-5ad8-4006-929b-eec300b45aeb.png"
  }, {
    title: "البرنامج التدريبي - الأمن السيبراني",
    organization: "أكاديمية منشآت",
    date: "2025",
    description: "برنامج تدريبي متخصص في الأمن السيبراني والحماية الرقمية",
    link: "https://academy.monshaat.gov.sa/pluginfile.php/1/mod_customcert/cert/586/9272-586-certificate-236057.png",
    image: "/lovable-uploads/ef64ff4e-f8b0-4400-867d-8288f8a83dd7.png"
  }, {
    title: "Full Stack Web Development",
    organization: "Meta Professional Certificate",
    date: "2024",
    description: "Advanced React, Node.js, and database management"
  }, {
    title: "UI/UX Design Specialization",
    organization: "Google Design Certificate",
    date: "2023",
    description: "User experience design and prototyping"
  }];
  return <section id="certificates" className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-6xl font-playfair font-bold luxury-gradient mb-6">شهاداتي</h2>
          
        </div>

        {/* Certificates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {certificates.map((cert, index) => (
            <div 
              key={index} 
              className="group glass-card p-8 rounded-2xl hover:scale-105 hover:glow-effect transition-all duration-500 animate-scale-in" 
              style={{ animationDelay: `${index * 0.1}s` }}
            >
                {/* Certificate Image or Icon */}
                {cert.image ? (
                  <div className="relative mb-6">
                    <div 
                      className="relative cursor-pointer group/image"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelectedImage({ src: cert.image!, title: cert.title });
                      }}
                    >
                      <img 
                        src={cert.image} 
                        alt={cert.title}
                        className="w-full h-48 object-cover rounded-xl border border-border/20 transition-all duration-300 group-hover/image:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover/image:opacity-100 transition-opacity duration-300 rounded-xl flex items-center justify-center">
                        <Expand className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="relative mb-6">
                    <div className="w-16 h-16 glass-card rounded-full flex items-center justify-center group-hover:bg-gradient-luxury transition-all duration-300">
                      <Award className="w-8 h-8 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
                    </div>
                    <div className="absolute inset-0 rounded-full bg-gradient-luxury opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
                  </div>
                )}

                {/* Certificate Content */}
                <div className="space-y-4">
                  <h3 className="text-xl font-playfair font-semibold text-foreground group-hover:text-primary transition-colors duration-300">
                    {cert.title}
                  </h3>
                  
                  <p className="text-secondary font-inter font-medium">
                    {cert.organization}
                  </p>
                  
                  <p className="text-muted-foreground font-inter leading-relaxed">
                    {cert.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-sm text-accent">
                      <Calendar className="w-4 h-4" />
                      <span className="font-inter">{cert.date}</span>
                    </div>
                    
                    {/* Show Certificate Button - Always visible */}
                    {cert.link ? (
                      <button 
                        onClick={(e) => {
                          console.log('Opening external link:', cert.link);
                          e.preventDefault();
                          e.stopPropagation();
                          window.open(cert.link, '_blank', 'noopener,noreferrer');
                        }}
                        className="flex items-center space-x-1 text-sm text-primary hover:text-primary/80 transition-colors duration-300 cursor-pointer z-10"
                      >
                        <span className="font-inter">عرض الشهادة</span>
                        <ExternalLink className="w-4 h-4" />
                      </button>
                    ) : cert.image ? (
                      <button 
                        onClick={(e) => {
                          console.log('Opening image modal for:', cert.title);
                          e.preventDefault();
                          e.stopPropagation();
                          setSelectedImage({ src: cert.image!, title: cert.title });
                        }}
                        className="flex items-center space-x-1 text-sm text-primary hover:text-primary/80 transition-colors duration-300 cursor-pointer z-10"
                      >
                        <span className="font-inter">عرض الشهادة</span>
                        <Expand className="w-4 h-4" />
                      </button>
                    ) : (
                      <span className="text-sm text-muted-foreground font-inter">شهادة رقمية</span>
                    )}
                  </div>
                </div>

                {/* Hover Border Effect */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-luxury opacity-0 group-hover:opacity-10 transition-opacity duration-500"></div>
              </div>
            ))}
        </div>

        {/* Image Modal */}
        <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
          <DialogContent className="max-w-4xl w-full p-0 overflow-hidden">
            {selectedImage && (
              <div className="relative">
                <img 
                  src={selectedImage.src} 
                  alt={selectedImage.title}
                  className="w-full h-auto max-h-[90vh] object-contain"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-6">
                  <h3 className="text-white text-lg font-playfair font-semibold">
                    {selectedImage.title}
                  </h3>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </section>;
};
export default CertificatesSection;