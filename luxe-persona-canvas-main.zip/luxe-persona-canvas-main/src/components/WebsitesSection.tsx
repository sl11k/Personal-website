import { ExternalLink } from "lucide-react";
const WebsitesSection = () => {
  const websites = [{
    title: "Helper Trendify",
    link: "https://helper.trendifysa.com"
  }, {
    title: "LPP KSA",
    link: "https://lppksa.com"
  }, {
    title: "Tag 10",
    link: "https://tag-10.com"
  }, {
    title: "Smo Al Mosafer",
    link: "https://smoalmosafer.com/ar/"
  }, {
    title: "Moon Al Hzaz",
    link: "https://moon-alhzaz.com"
  }, {
    title: "Maalem Shop",
    link: "https://maalem.shop"
  }, {
    title: "Social Trendify",
    link: "https://social.trendifysa.com"
  }];
  return <section id="websites" className="py-20 px-6 bg-gradient-to-b from-transparent to-muted/20">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-6xl font-playfair font-bold luxury-gradient mb-6">مواقع صممتها</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-inter">مجموعة من المواقع الإلكترونية والتجارب الرقمية المصممة باستخدام تقنيات حديثة</p>
        </div>

        {/* Websites List */}
        <div className="max-w-2xl mx-auto space-y-4">
          {websites.map((website, index) => <div key={index} className="glass-card rounded-xl p-6 hover:glow-effect transition-all duration-300 animate-fade-in-up" style={{
          animationDelay: `${index * 0.1}s`
        }}>
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-playfair font-semibold text-foreground">
                  {website.title}
                </h3>
                <a href={website.link} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors duration-300">
                  <span className="font-inter">زيارة الموقع</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>)}
        </div>
      </div>
    </section>;
};
export default WebsitesSection;