import profileImage from "@/assets/profile-photo.jpg";
import { Instagram, Twitter, Youtube, Video, Hash, Tv, Linkedin } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

const FixedHeader = () => {
  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    fetchLiveStatus();
  }, []);

  const fetchLiveStatus = async () => {
    try {
      const { data, error } = await supabase
        .from('kick_stats')
        .select('is_live')
        .order('updated_at', { ascending: false })
        .limit(1);

      if (error) {
        console.error('Error fetching live status:', error);
        return;
      }

      if (data && data.length > 0) {
        setIsLive(data[0].is_live);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <header className="glass-card backdrop-blur-xl">
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="flex flex-col items-center space-y-6">
          {/* Profile Image */}
          <div className="relative group">
            {/* Live indicator ring */}
            {isLive && (
              <div className="absolute inset-0 rounded-full border-4 border-red-500/60 animate-pulse">
                <div className="absolute inset-0 rounded-full border-4 border-red-400/40 animate-ping"></div>
              </div>
            )}
            
            <div className={`w-32 h-35 md:w-40 md:h-40 rounded-full overflow-hidden glass-card border-2 transition-all duration-500 ${
              isLive 
                ? 'border-red-500/40 shadow-[0_0_20px_rgba(239,68,68,0.3)]' 
                : 'border-primary/20 group-hover:border-primary/40'
            }`}>
              <img 
                src="/lovable-uploads/ea0f3034-8cf5-4525-9cb4-90d20442eeb6.png" 
                alt="Profile" 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                style={{ objectPosition: 'center 45%' }} 
              />
            </div>

            {/* Live button */}
            {isLive && (
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                <a 
                  href="https://kick.com/sl2k" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center px-3 py-1 bg-red-500 text-white rounded-full text-xs font-bold hover:bg-red-600 transition-colors duration-300 shadow-lg"
                >
                  <div className="w-2 h-2 bg-white rounded-full mr-1 animate-pulse"></div>
                  LIVE
                </a>
              </div>
            )}
          </div>

          {/* Name */}
          <h1 className="text-3xl md:text-4xl font-playfair font-bold text-foreground text-center">mhmd</h1>

          {/* Bio */}
          <p className="text-base md:text-lg text-muted-foreground text-center max-w-3xl leading-relaxed font-inter">
            طالب امن سيبراني<br />
            العقل مصري والقلب سعودي
          </p>

          {/* Social Media Icons */}
          <div className="flex justify-center space-x-2 rtl:space-x-reverse">
            {[
              {
                icon: Youtube,
                href: "https://www.youtube.com/@sl11.k",
                label: "YouTube"
              },
              {
                icon: Instagram,
                href: "https://www.instagram.com/sl11.k",
                label: "Instagram"
              },
              {
                icon: Video,
                href: "https://www.tiktok.com/@sl11.k",
                label: "TikTok"
              },
              {
                icon: Hash,
                href: "https://kick.com/sl2k",
                label: "Kick"
              },
              {
                icon: Twitter,
                href: "https://x.com/sl000k?s=21",
                label: "Twitter"
              },
              {
                icon: Linkedin,
                href: "https://www.linkedin.com/in/mohamed-samy-946121200/",
                label: "LinkedIn"
              }
            ].map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative p-3 glass-card rounded-full hover:scale-110 transition-all duration-300 border border-primary/30 hover:border-primary/60 bg-primary/10 hover:bg-primary/20"
                aria-label={label}
              >
                {label === "Kick" ? (
                  <span className="w-5 h-5 text-primary group-hover:text-accent transition-colors duration-300 flex items-center justify-center font-bold text-base">
                    K
                  </span>
                ) : (
                  <Icon className="w-5 h-5 text-primary group-hover:text-accent transition-colors duration-300" />
                )}
              </a>
            ))}
          </div>
        </div>
      </div>
    </header>
  );
};

export default FixedHeader;