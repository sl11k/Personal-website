import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const UpdateStatsButton = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const updateStats = async () => {
    setLoading(true);
    try {
      // Update YouTube stats
      const { data: youtubeData, error: youtubeError } = await supabase.functions.invoke('update-youtube-stats');
      
      if (youtubeError) {
        throw new Error(`YouTube stats update failed: ${youtubeError.message}`);
      }

      // Update Kick stats
      const { data: kickData, error: kickError } = await supabase.functions.invoke('update-kick-stats');
      
      if (kickError) {
        throw new Error(`Kick stats update failed: ${kickError.message}`);
      }

      toast({
        title: "تم التحديث بنجاح",
        description: "تم تحديث إحصائيات اليوتيوب و Kick",
      });

      // Refresh the page to show updated stats
      window.location.reload();
    } catch (error) {
      console.error('Error updating stats:', error);
      toast({
        title: "خطأ في التحديث",
        description: "حدث خطأ أثناء تحديث الإحصائيات",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button 
      onClick={updateStats} 
      disabled={loading}
      className="mb-4"
      variant="outline"
    >
      <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
      تحديث الإحصائيات
    </Button>
  );
};

export default UpdateStatsButton;