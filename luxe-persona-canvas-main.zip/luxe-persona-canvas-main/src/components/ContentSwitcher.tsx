import { TabType } from "./TabNavigation";
import CertificatesSection from "./CertificatesSection";
import WebsitesSection from "./WebsitesSection";
import MusicSection from "./MusicSection";
import VideosSection from "./VideosSection";
import GamingSection from "./GamingSection";

interface ContentSwitcherProps {
  activeTab: TabType;
}

const ContentSwitcher = ({ activeTab }: ContentSwitcherProps) => {
  const renderContent = () => {
    switch (activeTab) {
      case 'certificates':
        return <CertificatesSection />;
      case 'websites':
        return <WebsitesSection />;
      case 'music':
        return <MusicSection />;
      case 'videos':
        return <VideosSection />;
      case 'gaming':
        return <GamingSection />;
      default:
        return <CertificatesSection />;
    }
  };

  return (
    <main className="pb-20">
      <div key={activeTab} className="animate-tab-enter">
        {renderContent()}
      </div>
    </main>
  );
};

export default ContentSwitcher;