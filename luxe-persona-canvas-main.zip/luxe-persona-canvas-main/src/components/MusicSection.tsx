import { Play, Music, Heart, Eye } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
const MusicSection = () => {
  const [songStats, setSongStats] = useState({
    views: "0",
    likes: "0"
  });
  const songs = [{
    title: "Handle It",
    genre: "موسيقى عربية",
    duration: "3:45",
    views: songStats.views,
    likes: songStats.likes,
    thumbnail: "/lovable-uploads/a67cc7b8-a19b-47f3-ba84-5df2db34af45.png",
    youtubeId: "YnM1ibDi_is"
  }];
  useEffect(() => {
    const fetchVideoStats = async () => {
      try {
        const {
          data,
          error
        } = await supabase.functions.invoke('get-video-stats', {
          body: {
            videoId: 'YnM1ibDi_is'
          }
        });
        if (error) {
          console.error('Error fetching video stats:', error);
          return;
        }
        if (data?.success && data?.stats) {
          setSongStats({
            views: formatNumber(data.stats.views),
            likes: formatNumber(data.stats.likes)
          });
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };
    fetchVideoStats();
  }, []);
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };
  return <section id="music" className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-6xl font-playfair font-bold luxury-gradient mb-6">الاغاني الخاصة بي </h2>
          
        </div>

        {/* Music Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {songs.map((song, index) => <div key={index} className="group glass-card rounded-2xl overflow-hidden hover:scale-105 hover:glow-effect transition-all duration-500 animate-scale-in" style={{
          animationDelay: `${index * 0.1}s`
        }}>
              {/* Song Thumbnail */}
              <div className="relative h-48 overflow-hidden">
                <img src={song.thumbnail} alt={song.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-luxury opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
                
                {/* Play Button */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <button onClick={() => window.open(`https://www.youtube.com/watch?v=${song.youtubeId}`, '_blank')} className="w-16 h-16 glass-card rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 hover:scale-110 transition-all duration-300">
                    <Play className="w-6 h-6 text-primary ml-1" />
                  </button>
                </div>

                {/* Duration Badge */}
                <div className="absolute bottom-4 right-4">
                  <span className="px-2 py-1 glass-card text-xs font-inter font-medium text-foreground rounded">
                    {song.duration}
                  </span>
                </div>

                {/* Genre Badge */}
                <div className="absolute top-4 left-4">
                  
                </div>
              </div>

              {/* Song Info */}
              <div className="p-6 space-y-4">
                <h3 className="text-xl font-playfair font-semibold text-foreground group-hover:text-primary transition-colors duration-300">
                  {song.title}
                </h3>

                {/* Stats */}
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Eye className="w-4 h-4" />
                      <span className="font-inter">{song.views}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Heart className="w-4 h-4" />
                      <span className="font-inter">{song.likes}</span>
                    </div>
                  </div>
                  <Music className="w-4 h-4 text-secondary" />
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-2 pt-4">
                  <button onClick={() => window.open(`https://www.youtube.com/watch?v=${song.youtubeId}`, '_blank')} className="flex-1 glass-card py-2 px-4 rounded-lg text-sm font-inter font-medium text-primary hover:bg-primary hover:text-primary-foreground transition-colors duration-300">
                    Listen on YouTube
                  </button>
                </div>
              </div>
            </div>)}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <button className="px-8 py-4 glass-card rounded-full font-inter font-medium text-primary hover:bg-gradient-luxury hover:text-primary-foreground transition-all duration-300 hover:scale-105">
            View All Music →
          </button>
        </div>
      </div>
    </section>;
};
export default MusicSection;