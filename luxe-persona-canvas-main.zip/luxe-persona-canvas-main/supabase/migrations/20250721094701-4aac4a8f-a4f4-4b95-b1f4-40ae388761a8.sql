-- Create table for YouTube channel statistics
CREATE TABLE public.youtube_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  channel_id TEXT NOT NULL UNIQUE,
  channel_name TEXT NOT NULL,
  subscriber_count BIGINT NOT NULL DEFAULT 0,
  video_count BIGINT NOT NULL DEFAULT 0,
  view_count BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.youtube_stats ENABLE ROW LEVEL SECURITY;

-- Create policy to allow public read access
CREATE POLICY "Anyone can view YouTube stats" 
ON public.youtube_stats 
FOR SELECT 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_youtube_stats_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_youtube_stats_updated_at
  BEFORE UPDATE ON public.youtube_stats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_youtube_stats_updated_at();

-- Insert initial data for the channel
INSERT INTO public.youtube_stats (channel_id, channel_name, subscriber_count, video_count, view_count)
VALUES ('UCsl11k', 'sl11.k', 0, 0, 0)
ON CONFLICT (channel_id) DO NOTHING;