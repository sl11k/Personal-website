-- Enable pg_cron extension for scheduled tasks
SELECT cron.schedule(
  'daily-youtube-stats-update',
  '0 6 * * *', -- Every day at 6 AM
  $$
  SELECT
    net.http_post(
        url:='https://qafaknoryqfjpvlacpty.supabase.co/functions/v1/update-youtube-stats',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFhZmFrbm9yeXFmanB2bGFjcHR5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMwOTA0NjAsImV4cCI6MjA2ODY2NjQ2MH0.jU-aprYQHQDUuPCBbjUL2-t36plpKv96L0pctEhnoiM"}'::jsonb,
        body:='{}'::jsonb
    ) as request_id;
  $$
);