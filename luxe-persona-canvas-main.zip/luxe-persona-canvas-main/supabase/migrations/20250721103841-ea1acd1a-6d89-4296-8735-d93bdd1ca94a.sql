-- Create table for Kick channel statistics
CREATE TABLE public.kick_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  channel_slug TEXT NOT NULL UNIQUE,
  channel_name TEXT NOT NULL,
  follower_count BIGINT NOT NULL DEFAULT 0,
  live_viewer_count BIGINT NOT NULL DEFAULT 0,
  total_views BIGINT NOT NULL DEFAULT 0,
  is_live BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.kick_stats ENABLE ROW LEVEL SECURITY;

-- Create policy to allow public read access
CREATE POLICY "Anyone can view Kick stats" 
ON public.kick_stats 
FOR SELECT 
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_kick_stats_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_kick_stats_updated_at
  BEFORE UPDATE ON public.kick_stats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_kick_stats_updated_at();

-- Insert initial data for your channel
INSERT INTO public.kick_stats (channel_slug, channel_name, follower_count, live_viewer_count, total_views, is_live)
VALUES ('sl2k', 'sl2k', 0, 0, 0, false)
ON CONFLICT (channel_slug) DO NOTHING;