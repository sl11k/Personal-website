import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const YOUTUBE_API_KEY = Deno.env.get('YOUTUBE_API_KEY');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!YOUTUBE_API_KEY) {
      throw new Error('YouTube API key not configured');
    }

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error('Supabase configuration missing');
    }

    // Initialize Supabase client with service role key
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // First, get channel ID from username
    const channelResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/channels?part=id,statistics,snippet&forUsername=sl11.k&key=${YOUTUBE_API_KEY}`
    );

    let channelData = await channelResponse.json();
    
    // If forUsername doesn't work, try searching by handle
    if (!channelData.items || channelData.items.length === 0) {
      const searchResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=@sl11.k&key=${YOUTUBE_API_KEY}`
      );
      
      const searchData = await searchResponse.json();
      
      if (searchData.items && searchData.items.length > 0) {
        const channelId = searchData.items[0].snippet.channelId;
        
        // Get detailed channel statistics
        const detailResponse = await fetch(
          `https://www.googleapis.com/youtube/v3/channels?part=statistics,snippet&id=${channelId}&key=${YOUTUBE_API_KEY}`
        );
        
        channelData = await detailResponse.json();
      }
    }

    if (!channelData.items || channelData.items.length === 0) {
      throw new Error('Channel not found');
    }

    const channel = channelData.items[0];
    const stats = channel.statistics;
    const snippet = channel.snippet;

    console.log('Channel found:', snippet.title);
    console.log('Channel ID:', channel.id);
    console.log('Statistics:', stats);

    // Update the database using the actual channel ID found
    const { data, error } = await supabase
      .from('youtube_stats')
      .upsert({
        channel_id: channel.id,
        channel_name: snippet.title,
        subscriber_count: parseInt(stats.subscriberCount || '0'),
        video_count: parseInt(stats.videoCount || '0'),
        view_count: parseInt(stats.viewCount || '0'),
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'channel_id'
      });

    if (error) {
      console.error('Database error:', error);
      throw error;
    }

    console.log('Successfully updated YouTube stats for channel:', channel.id);

    return new Response(JSON.stringify({
      success: true,
      stats: {
        subscribers: parseInt(stats.subscriberCount || '0'),
        videos: parseInt(stats.videoCount || '0'),
        views: parseInt(stats.viewCount || '0'),
        channelName: snippet.title
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in update-youtube-stats function:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});