import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error('Supabase configuration missing');
    }

    // Initialize Supabase client with service role key
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Channel slug to fetch data for
    const channelSlug = 'sl2k';

    console.log('Fetching Kick data for channel:', channelSlug);

    // Try to fetch channel data from Kick's unofficial API
    const response = await fetch(`https://kick.com/api/v2/channels/${channelSlug}`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch channel data: ${response.status}`);
    }

    const channelData = await response.json();
    
    console.log('Channel data received:', channelData);

    // Extract relevant statistics
    const followerCount = channelData.followers_count || 0;
    const isLive = channelData.livestream ? true : false;
    const liveViewerCount = channelData.livestream?.viewer_count || 0;
    const channelName = channelData.user?.username || channelSlug;

    // For total views, we'll need to make an additional request or use available data
    // Kick doesn't provide total views in the main API, so we'll set it to 0 for now
    const totalViews = 0;

    console.log('Extracted stats:', {
      followerCount,
      isLive,
      liveViewerCount,
      channelName,
      totalViews
    });

    // Update the database
    const { data, error } = await supabase
      .from('kick_stats')
      .upsert({
        channel_slug: channelSlug,
        channel_name: channelName,
        follower_count: followerCount,
        live_viewer_count: liveViewerCount,
        total_views: totalViews,
        is_live: isLive,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'channel_slug'
      });

    if (error) {
      console.error('Database error:', error);
      throw error;
    }

    console.log('Successfully updated Kick stats for channel:', channelSlug);

    return new Response(JSON.stringify({
      success: true,
      stats: {
        followers: followerCount,
        liveViewers: liveViewerCount,
        totalViews: totalViews,
        isLive: isLive,
        channelName: channelName
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in update-kick-stats function:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      success: false 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});