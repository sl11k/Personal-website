import { useState, useEffect } from "react";
import FixedHeader from "@/components/FixedHeader";
import ProtectedFooter from "@/components/ProtectedFooter";
import TabNavigation, { TabType } from "@/components/TabNavigation";
import ContentSwitcher from "@/components/ContentSwitcher";

const Index = () => {
  const [activeTab, setActiveTab] = useState<TabType>('certificates');
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: e.clientX,
        y: e.clientY
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="min-h-screen relative smooth-scroll">
      {/* Video Background */}
      <div className="fixed inset-0 w-full h-full z-0 overflow-hidden">
        <video 
          autoPlay 
          loop 
          muted 
          playsInline
          className="absolute inset-0 w-full h-full object-cover border-none"
          style={{
            width: '100vw',
            height: '100vh',
            minWidth: '177.78vh', // 16:9 aspect ratio to ensure full coverage
            minHeight: '56.25vw',  // 16:9 aspect ratio to ensure full coverage
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)'
          }}
        >
          <source src="https://qafaknoryqfjpvlacpty.supabase.co/storage/v1/object/public/background//goku-ultra-instinct_2.3840x2160.mp4" type="video/mp4" />
        </video>
        {/* Dark overlay for better text readability */}
        <div className="absolute inset-0 bg-black/30 z-10"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-20">
        <FixedHeader />
        <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />
        <ContentSwitcher activeTab={activeTab} />
      </div>
      
      {/* Protected Footer */}
      <ProtectedFooter />
    </div>
  );
};

export default Index;
