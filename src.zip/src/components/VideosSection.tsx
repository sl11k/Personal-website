import { Play, Eye, Clock, Sparkles } from "lucide-react";
const VideosSection = () => {
  const videos3D = [{
    title: "Futuristic City Animation",
    description: "Cyberpunk-inspired cityscape with dynamic lighting",
    duration: "2:34",
    views: "45K",
    thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176",
    software: "Blender",
    category: "Architecture"
  }, {
    title: "Abstract Particle System",
    description: "Mesmerizing particle simulation with fluid dynamics",
    duration: "1:45",
    views: "78K",
    thumbnail: "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4",
    software: "Houdini",
    category: "VFX"
  }, {
    title: "Character Animation Reel",
    description: "Showcase of character rigging and animation",
    duration: "3:12",
    views: "92K",
    thumbnail: "https://images.unsplash.com/photo-1550745165-9bc0b252726f",
    software: "Maya",
    category: "Character"
  }, {
    title: "Product Visualization",
    description: "Luxury watch rendering with photorealistic materials",
    duration: "1:28",
    views: "156K",
    thumbnail: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
    software: "Cinema 4D",
    category: "Product"
  }, {
    title: "Motion Graphics Logo",
    description: "Dynamic brand identity animation sequence",
    duration: "0:45",
    views: "234K",
    thumbnail: "https://images.unsplash.com/photo-1611224923853-80b023f02d71",
    software: "After Effects",
    category: "Motion"
  }, {
    title: "Environmental Concept",
    description: "Fantasy landscape with atmospheric effects",
    duration: "4:21",
    views: "67K",
    thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4",
    software: "Blender",
    category: "Environment"
  }];
  return <section id="videos-3d" className="py-20 px-6 bg-gradient-to-b from-muted/10 to-transparent">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-6xl font-playfair font-bold luxury-gradient mb-6">3D models</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto font-inter">مودلات من تصميميي</p>
        </div>

      </div>
    </section>;
};
export default VideosSection;