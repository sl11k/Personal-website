import { useState } from "react";

export type TabType = 'certificates' | 'websites' | 'music' | 'videos' | 'gaming';

interface TabNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const TabNavigation = ({ activeTab, onTabChange }: TabNavigationProps) => {
  const tabs = [
    { id: 'certificates' as TabType, label: 'الشهادات' },
    { id: 'websites' as TabType, label: 'المواقع' },
    { id: 'music' as TabType, label: 'الموسيقى' },
    { id: 'videos' as TabType, label: 'الفيديوهات ثلاثية الأبعاد' },
    { id: 'gaming' as TabType, label: 'الألعاب' },
  ];

  return (
    <div className="backdrop-blur-xl bg-background/90 border-y border-border shadow-lg">
      <div className="max-w-6xl mx-auto px-6 py-6">
        <nav className="flex justify-center">
          <div className="flex flex-wrap justify-center gap-3 md:gap-4 glass-card rounded-2xl p-3">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`
                  px-5 md:px-7 py-3 md:py-4 rounded-xl font-inter font-medium transition-all duration-300 text-sm md:text-base
                  ${activeTab === tab.id 
                    ? 'bg-primary text-primary-foreground shadow-lg scale-105 border border-primary/20' 
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted/50 hover:scale-105 border border-transparent'
                  }
                `}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </nav>
      </div>
    </div>
  );
};

export default TabNavigation;