import { Play, Eye, Clock, Trophy, Gamepad2, Users, Tv } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import UpdateStatsButton from "./UpdateStatsButton";
const GamingSection = () => {
  const [youtubeStats, setYoutubeStats] = useState({
    subscriber_count: 0,
    video_count: 0,
    view_count: 0,
    loading: true
  });
  const [kickStats, setKickStats] = useState({
    follower_count: 0,
    live_viewer_count: 0,
    total_views: 0,
    is_live: false,
    loading: true
  });
  useEffect(() => {
    fetchYouTubeStats();
    fetchKickStats();
  }, []);
  const fetchKickStats = async () => {
    try {
      const {
        data,
        error
      } = await supabase.from('kick_stats').select('*').order('updated_at', {
        ascending: false
      }).limit(1);
      if (error) {
        console.error('Error fetching Kick stats:', error);
        return;
      }
      if (data && data.length > 0) {
        const stats = data[0];
        setKickStats({
          follower_count: stats.follower_count,
          live_viewer_count: stats.live_viewer_count,
          total_views: stats.total_views,
          is_live: stats.is_live,
          loading: false
        });
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setKickStats(prev => ({
        ...prev,
        loading: false
      }));
    }
  };
  const fetchYouTubeStats = async () => {
    try {
      // First try to get stats for any channel
      const {
        data,
        error
      } = await supabase.from('youtube_stats').select('*').order('updated_at', {
        ascending: false
      }).limit(1);
      if (error) {
        console.error('Error fetching YouTube stats:', error);
        return;
      }
      if (data && data.length > 0) {
        const stats = data[0];
        setYoutubeStats({
          subscriber_count: stats.subscriber_count,
          video_count: stats.video_count,
          view_count: stats.view_count,
          loading: false
        });
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setYoutubeStats(prev => ({
        ...prev,
        loading: false
      }));
    }
  };
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };
  const gamingVideos = [{
    title: "Epic Boss Fight Compilation",
    game: "Elden Ring",
    description: "Challenging boss encounters with perfect execution",
    duration: "12:45",
    views: "234K",
    likes: "18.2K",
    thumbnail: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f",
    category: "Boss Fights",
    difficulty: "Expert"
  }, {
    title: "Speed Run World Record",
    game: "Hollow Knight",
    description: "Any% speedrun with commentary and strategies",
    duration: "8:23",
    views: "456K",
    likes: "32.1K",
    thumbnail: "https://images.unsplash.com/photo-1542751371-adc38448a05e",
    category: "Speedrun",
    difficulty: "Professional"
  }, {
    title: "Building the Ultimate Base",
    game: "Valheim",
    description: "Complete guide to Viking fortress construction",
    duration: "15:32",
    views: "189K",
    likes: "14.7K",
    thumbnail: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc",
    category: "Tutorial",
    difficulty: "Intermediate"
  }, {
    title: "Ranked Climb Highlights",
    game: "Valorant",
    description: "From Silver to Diamond - Best moments compilation",
    duration: "9:17",
    views: "345K",
    likes: "28.4K",
    thumbnail: "https://images.unsplash.com/photo-1560253023-3ec5d502959f",
    category: "Competitive",
    difficulty: "Advanced"
  }, {
    title: "Indie Game Reviews",
    game: "Various",
    description: "Hidden gems and must-play indie titles",
    duration: "18:45",
    views: "123K",
    likes: "9.8K",
    thumbnail: "https://images.unsplash.com/photo-1511512578047-dfb367046420",
    category: "Reviews",
    difficulty: "All Levels"
  }, {
    title: "Co-op Campaign Playthrough",
    game: "It Takes Two",
    description: "Full campaign with friends and hilarious moments",
    duration: "45:12",
    views: "67K",
    likes: "5.3K",
    thumbnail: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8",
    category: "Co-op",
    difficulty: "Casual"
  }];
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Expert':
      case 'Professional':
        return 'text-red-400';
      case 'Advanced':
        return 'text-orange-400';
      case 'Intermediate':
        return 'text-yellow-400';
      default:
        return 'text-green-400';
    }
  };
  return <section id="gaming" className="py-20 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-6xl font-playfair font-bold luxury-gradient mb-6">
            عالم الألعاب
          </h2>
          
        </div>
        
        {/* Update Stats Button */}
        <div className="text-center mb-6">
          <UpdateStatsButton />
        </div>

        {/* Live Stream Status */}
        {!kickStats.loading && (
          <div className="mb-16">
            <div className="max-w-4xl mx-auto">
              {kickStats.is_live ? (
                <div className="glass-card p-8 rounded-2xl text-center mb-8 border-2 border-green-500/20">
                  <div className="flex items-center justify-center mb-4">
                    <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold mr-3 animate-pulse">
                      LIVE
                    </div>
                    <Tv className="w-8 h-8 text-green-500" />
                  </div>
                  <h3 className="text-3xl font-playfair font-bold luxury-gradient mb-3">
                    البث المباشر الآن!
                  </h3>
                  <p className="text-muted-foreground font-inter mb-2">
                    {formatNumber(kickStats.live_viewer_count)} مشاهد حالياً
                  </p>
                  <div className="mt-6">
                    <a 
                      href="https://kick.com/sl2k" 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center px-8 py-4 bg-gradient-luxury text-primary-foreground rounded-full font-inter font-bold text-lg hover:scale-105 transition-transform duration-300 shadow-lg"
                    >
                      <Tv className="w-5 h-5 mr-2" />
                      شاهد البث الآن
                    </a>
                  </div>
                </div>
              ) : (
                <div className="glass-card p-6 rounded-xl text-center mb-8 opacity-75">
                  <div className="flex items-center justify-center mb-3">
                    <Tv className="w-6 h-6 text-muted-foreground mr-2" />
                  </div>
                  <h3 className="text-xl font-playfair font-semibold text-muted-foreground mb-2">
                    البث غير مفتوح حالياً
                  </h3>
                  <p className="text-sm text-muted-foreground font-inter">
                    تابعني على Kick لتلقي إشعارات البث المباشر
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Platform Statistics */}
        {(!youtubeStats.loading || !kickStats.loading) && <div className="mb-16">
            <h3 className="text-2xl font-playfair font-bold luxury-gradient text-center mb-8">
              إحصائيات المنصات
            </h3>
            
            {/* YouTube Statistics Row */}
            {!youtubeStats.loading && <div className="mb-8">
                <h4 className="text-lg font-playfair font-semibold text-center mb-4 text-red-500">
                  اليوتيوب
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="glass-card p-6 rounded-xl text-center group hover:scale-105 transition-transform duration-300">
                    <Users className="w-8 h-8 text-red-500 mx-auto mb-3" />
                    <h4 className="text-2xl font-playfair font-bold luxury-gradient mb-2">
                      {formatNumber(youtubeStats.subscriber_count)}
                    </h4>
                    <p className="text-muted-foreground font-inter">مشترك</p>
                  </div>
                  
                  <div className="glass-card p-6 rounded-xl text-center group hover:scale-105 transition-transform duration-300">
                    <Play className="w-8 h-8 text-red-500 mx-auto mb-3" />
                    <h4 className="text-2xl font-playfair font-bold luxury-gradient mb-2">
                      {formatNumber(youtubeStats.video_count)}
                    </h4>
                    <p className="text-muted-foreground font-inter">فيديو</p>
                  </div>
                  
                  <div className="glass-card p-6 rounded-xl text-center group hover:scale-105 transition-transform duration-300">
                    <Eye className="w-8 h-8 text-red-500 mx-auto mb-3" />
                    <h4 className="text-2xl font-playfair font-bold luxury-gradient mb-2">
                      {formatNumber(youtubeStats.view_count)}
                    </h4>
                    <p className="text-muted-foreground font-inter">مشاهدة</p>
                  </div>
                </div>
              </div>}

            {/* Kick Statistics Row */}
            {!kickStats.loading && <div>
                <h4 className="text-lg font-playfair font-semibold text-center mb-4 text-green-500">
                  Kick
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="glass-card p-6 rounded-xl text-center group hover:scale-105 transition-transform duration-300">
                    <Users className="w-8 h-8 text-green-500 mx-auto mb-3" />
                    <h4 className="text-2xl font-playfair font-bold luxury-gradient mb-2">
                      {formatNumber(kickStats.follower_count)}
                    </h4>
                    <p className="text-muted-foreground font-inter">متابع</p>
                  </div>
                  
                  <div className="glass-card p-6 rounded-xl text-center group hover:scale-105 transition-transform duration-300 relative">
                    <Tv className="w-8 h-8 text-green-500 mx-auto mb-3" />
                    <h4 className="text-2xl font-playfair font-bold luxury-gradient mb-2">
                      {formatNumber(kickStats.live_viewer_count)}
                    </h4>
                    <p className="text-muted-foreground font-inter">مشاهد حالي</p>
                    {kickStats.is_live && <div className="absolute top-2 right-2">
                        <div className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                          LIVE
                        </div>
                      </div>}
                  </div>
                  
                  <div className="glass-card p-6 rounded-xl text-center group hover:scale-105 transition-transform duration-300">
                    <Eye className="w-8 h-8 text-green-500 mx-auto mb-3" />
                    <h4 className="text-2xl font-playfair font-bold luxury-gradient mb-2">
                      {formatNumber(kickStats.total_views)}
                    </h4>
                    <p className="text-muted-foreground font-inter">إجمالي المشاهدات</p>
                  </div>
                </div>
              </div>}
          </div>}

        {/* Gaming Channel CTA */}
        <div className="text-center mt-16">
          <div className="glass-card p-8 rounded-2xl max-w-2xl mx-auto">
            <div className="flex items-center justify-center mb-4">
              <Gamepad2 className="w-12 h-12 text-primary" />
            </div>
            <h3 className="text-2xl font-playfair font-semibold luxury-gradient mb-4">انضم لنا</h3>
            <p className="text-muted-foreground font-inter mb-6">متابعتك وانضمامك لي يعتبر شرف لي</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="https://www.youtube.com/@sl11.k" target="_blank" rel="noopener noreferrer" className="px-6 py-3 bg-gradient-luxury text-primary-foreground rounded-full font-inter font-medium hover:scale-105 transition-transform duration-300">
                اشترك في اليوتيوب
              </a>
              <a href="https://kick.com/sl2k" target="_blank" rel="noopener noreferrer" className="px-6 py-3 glass-card rounded-full font-inter font-medium text-primary hover:bg-primary hover:text-primary-foreground transition-colors duration-300">
                تابع على Kick
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default GamingSection;