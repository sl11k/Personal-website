import { Github } from "lucide-react";

const ProtectedFooter = () => {
  // Encoded data to make it harder to modify
  const encodedData = {
    author: btoa("this website made by mhmd"),
    repo: btoa("git@github.com:sl11k/Personal-website.git"),
    text: btoa("the source code")
  };

  const handleSourceClick = () => {
    const repoUrl = atob(encodedData.repo);
    // Convert git SSH URL to HTTPS GitHub URL
    const httpsUrl = repoUrl.replace('git@github.com:', 'https://github.com/').replace('.git', '');
    window.open(httpsUrl, '_blank', 'noopener,noreferrer');
  };

  // Additional obfuscation
  const renderContent = () => {
    const author = atob(encodedData.author);
    const sourceText = atob(encodedData.text);
    
    return (
      <footer className="bg-black/90 backdrop-blur-sm border-t border-border/20 mt-auto">
        <div className="max-w-7xl mx-auto px-6 py-3">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-sm">
            <p className="text-muted-foreground">
              {author}
            </p>
            <button
              onClick={handleSourceClick}
              className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors duration-300 cursor-pointer"
            >
              <Github className="w-4 h-4" />
              <span>{sourceText}</span>
            </button>
          </div>
        </div>
      </footer>
    );
  };

  return renderContent();
};

export default ProtectedFooter;