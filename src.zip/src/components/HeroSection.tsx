const profileImage = "/lovable-uploads/d6b0ccd6-1532-4871-872a-fa0fae132dad.png";
import { Instagram, Twitter, Youtube } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center px-6 py-20 relative">
      {/* Floating particles effect */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-2 h-2 bg-primary/30 rounded-full animate-float" style={{ top: '20%', left: '10%', animationDelay: '0s' }}></div>
        <div className="absolute w-1 h-1 bg-accent/40 rounded-full animate-float" style={{ top: '40%', right: '15%', animationDelay: '2s' }}></div>
        <div className="absolute w-1.5 h-1.5 bg-secondary/30 rounded-full animate-float" style={{ bottom: '30%', left: '20%', animationDelay: '4s' }}></div>
      </div>

      <div className="text-center space-y-8 animate-fade-in-up">
        {/* Profile Image */}
        <div className="relative inline-block group">
          <div className="w-48 h-48 md:w-64 md:h-64 rounded-full overflow-hidden glass-card glow-effect group-hover:scale-105 transition-transform duration-500">
            <img 
              src={profileImage} 
              alt="Profile" 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute inset-0 rounded-full bg-gradient-luxury opacity-0 group-hover:opacity-20 transition-opacity duration-500"></div>
        </div>

        {/* Name */}
        <h1 className="text-5xl md:text-7xl font-playfair font-bold luxury-gradient leading-tight">
          Your Name Here
        </h1>

        {/* Bio */}
        <div className="max-w-2xl mx-auto">
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed font-inter">
            Creative developer, musician, and digital artist crafting immersive experiences 
            through code, sound, and visual storytelling. Passionate about pushing the boundaries 
            of technology and creativity.
          </p>
        </div>

        {/* Social Media Icons */}
        <div className="flex justify-center space-x-6 mt-12">
          {[
            { icon: Instagram, href: "#", label: "Instagram" },
            { icon: Twitter, href: "#", label: "Twitter" },
            { icon: Youtube, href: "#", label: "YouTube" },
          ].map(({ icon: Icon, href, label }) => (
            <a
              key={label}
              href={href}
              className="group relative p-4 glass-card rounded-full hover:scale-110 transition-all duration-300 hover:glow-effect"
              aria-label={label}
            >
              <Icon className="w-6 h-6 text-primary group-hover:text-accent transition-colors duration-300" />
              <div className="absolute inset-0 rounded-full bg-gradient-luxury opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HeroSection;